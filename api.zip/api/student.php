<?php
 
 include 'header.php';
 include 'connection-pdo.php';
 
 class Student{
     private $conn;
 
     public function __construct($connection) {
         $this->conn = $connection;
     }

     private function normalizeChecklistStatus($value, $default = 1) {
        if ($value === null) return (int)$default;
        if (is_bool($value)) return $value ? 1 : 0;
        if (is_numeric($value)) {
            $num = (int)$value;
            return in_array($num, [0, 1], true) ? $num : (int)$default;
        }
        $v = strtolower(trim((string)$value));
        if (in_array($v, ['true', 'yes', 'on', 'ok', 'good'], true)) return 1;
        if (in_array($v, ['false', 'no', 'off', 'not ok', 'bad'], true)) return 0;
        return (int)$default;
    }

    private function normalizeAssignedStatus($value) {
        if ($value === null) return null;
        $v = strtolower(trim((string)$value));
        $map = [
            'excellent' => 'Excellent',
            'good' => 'Good',
            'fair' => 'Fair',
            'poor' => 'Poor'
        ];
        return $map[$v] ?? null;
    }

    public function getTodayActivity($data) {
        try {
            if (!is_array($data) || !isset($data['assigned_user_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_user_id'
                ]);
            }

            $assigned_user_id = (int)$data['assigned_user_id'];
            if ($assigned_user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_user_id.'
                ]);
            }

            $opStmt = $this->conn->prepare('SELECT COUNT(*) AS activity_count, MAX(operation_updated_at) AS last_operation_at FROM tblassignedoperation WHERE operation_updated_by = ? AND DATE(operation_updated_at) = CURDATE()');
            $opStmt->execute([$assigned_user_id]);
            $opRow = $opStmt->fetch(PDO::FETCH_ASSOC);

            $statusStmt = $this->conn->prepare('SELECT COUNT(*) AS rooms_inspected, MAX(assigned_updated_at) AS last_inspection_at FROM tblassignedstatus WHERE assigned_reported_by = ? AND completion_date = CURDATE()');
            $statusStmt->execute([$assigned_user_id]);
            $statusRow = $statusStmt->fetch(PDO::FETCH_ASSOC);

            $activityCount = isset($opRow['activity_count']) ? (int)$opRow['activity_count'] : 0;
            $roomsInspected = isset($statusRow['rooms_inspected']) ? (int)$statusRow['rooms_inspected'] : 0;

            $lastActivityAt = null;
            $lastOpAt = $opRow['last_operation_at'] ?? null;
            $lastInspectionAt = $statusRow['last_inspection_at'] ?? null;
            if ($lastOpAt && $lastInspectionAt) {
                $lastActivityAt = (strtotime($lastOpAt) >= strtotime($lastInspectionAt)) ? $lastOpAt : $lastInspectionAt;
            } elseif ($lastOpAt) {
                $lastActivityAt = $lastOpAt;
            } elseif ($lastInspectionAt) {
                $lastActivityAt = $lastInspectionAt;
            }

            return json_encode([
                'success' => true,
                'data' => [
                    'activity_count' => $activityCount,
                    'rooms_inspected' => $roomsInspected,
                    'last_activity_at' => $lastActivityAt,
                    'is_active_today' => ($activityCount > 0) || ($roomsInspected > 0)
                ]
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getAssignments($data) {
        try {
            if (!is_array($data) || !isset($data['assigned_user_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_user_id'
                ]);
            }

            $assigned_user_id = (int)$data['assigned_user_id'];
            if ($assigned_user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_user_id.'
                ]);
            }

            $stmt = $this->conn->prepare('SELECT a.assigned_id, a.assigned_user_id, a.assigned_floor_building_id, bf.building_id, b.building_name, bf.floor_id, f.floor_name, a.assigned_start_date, a.assigned_end_date, a.assigned_by_user_id, a.assigned_created_at FROM tblassigned a JOIN tblbuildingfloor bf ON bf.floorbuilding_id = a.assigned_floor_building_id JOIN tblbuilding b ON b.building_id = bf.building_id JOIN tblfloor f ON f.floor_id = bf.floor_id WHERE a.assigned_user_id = ? ORDER BY a.assigned_created_at DESC');
            $stmt->execute([$assigned_user_id]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return json_encode([
                'success' => true,
                'data' => $rows
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getMissedClassrooms($data) {
        try {
            if (!is_array($data) || !isset($data['assigned_user_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_user_id'
                ]);
            }

            $assigned_user_id = (int)$data['assigned_user_id'];
            if ($assigned_user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_user_id.'
                ]);
            }

            $date = $data['date'] ?? date('Y-m-d');
            $d = DateTime::createFromFormat('Y-m-d', $date);
            if (!$d || $d->format('Y-m-d') !== $date) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid date format. Use YYYY-MM-DD.'
                ]);
            }

            $assigned_floor_building_id = null;
            if (isset($data['assigned_floor_building_id']) && $data['assigned_floor_building_id'] !== '') {
                $assigned_floor_building_id = (int)$data['assigned_floor_building_id'];
            }
            if (!$assigned_floor_building_id) {
                $active = $this->getCurrentAssignment(['assigned_user_id' => $assigned_user_id]);
                $decoded = json_decode($active, true);
                if (is_array($decoded) && ($decoded['success'] ?? false) && is_array($decoded['data'] ?? null)) {
                    $assigned_floor_building_id = (int)($decoded['data']['assigned_floor_building_id'] ?? 0);
                }
            }
            if (!$assigned_floor_building_id) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_floor_building_id (or provide assigned_user_id with an assignment)'
                ]);
            }

            $missedStmt = $this->conn->prepare('
                SELECT
                    r.room_id,
                    r.room_number,
                    bf.building_id,
                    b.building_name,
                    bf.floor_id,
                    f.floor_name
                FROM tblroom r
                JOIN tblbuildingfloor bf ON bf.floorbuilding_id = r.room_building_floor_id
                JOIN tblbuilding b ON b.building_id = bf.building_id
                JOIN tblfloor f ON f.floor_id = bf.floor_id
                LEFT JOIN tblassignedstatus s
                    ON s.room_id = r.room_id
                    AND s.assigned_reported_by = ?
                    AND s.completion_date = ?
                WHERE r.room_building_floor_id = ?
                  AND s.assigned_status_id IS NULL
                ORDER BY r.room_number ASC
            ');
            $missedStmt->execute([$assigned_user_id, $date, $assigned_floor_building_id]);
            $rooms = $missedStmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($rooms) === 0) {
                return json_encode([
                    'success' => true,
                    'data' => []
                ]);
            }

            $roomIds = array_map(function ($r) {
                return (int)$r['room_id'];
            }, $rooms);
            $placeholders = implode(',', array_fill(0, count($roomIds), '?'));

            $checklistStmt = $this->conn->prepare('
                SELECT
                    r.room_id,
                    c.checklist_id,
                    c.checklist_name,
                    c.checklist_type,
                    c.checklist_quantity,
                    o.operation_is_functional,
                    o.operation_quantity,
                    o.operation_condition,
                    o.operation_updated_at
                FROM tblroom r
                JOIN tblroomchecklist c ON c.checklist_room_id = r.room_id
                LEFT JOIN (
                    SELECT ao1.operation_room_id, ao1.operation_checklist_id, ao1.operation_is_functional, ao1.operation_quantity, ao1.operation_condition, ao1.operation_updated_at
                    FROM tblassignedoperation ao1
                    INNER JOIN (
                        SELECT operation_room_id, operation_checklist_id, MAX(operation_updated_at) AS max_updated_at
                        FROM tblassignedoperation
                        WHERE operation_updated_by = ? AND DATE(operation_updated_at) = ?
                        GROUP BY operation_room_id, operation_checklist_id
                    ) ao2
                        ON ao2.operation_room_id = ao1.operation_room_id
                        AND ao2.operation_checklist_id = ao1.operation_checklist_id
                        AND ao2.max_updated_at = ao1.operation_updated_at
                    WHERE ao1.operation_updated_by = ? AND DATE(ao1.operation_updated_at) = ?
                ) o
                    ON o.operation_room_id = r.room_id
                    AND o.operation_checklist_id = c.checklist_id
                WHERE r.room_id IN (' . $placeholders . ')
                ORDER BY r.room_id ASC, c.checklist_name ASC
            ');

            $params = [$assigned_user_id, $date, $assigned_user_id, $date];
            foreach ($roomIds as $rid) {
                $params[] = $rid;
            }
            $checklistStmt->execute($params);
            $checklistRows = $checklistStmt->fetchAll(PDO::FETCH_ASSOC);

            $byRoom = [];
            foreach ($checklistRows as $cr) {
                $rid = (int)$cr['room_id'];
                if (!isset($byRoom[$rid])) $byRoom[$rid] = [];
                $byRoom[$rid][] = [
                    'checklist_id' => (int)$cr['checklist_id'],
                    'checklist_name' => $cr['checklist_name'],
                    'checklist_type' => $cr['checklist_type'] ?? 'boolean',
                    'checklist_quantity' => $cr['checklist_quantity'] ?? null,
                    'operation_is_functional' => $cr['operation_is_functional'] === null ? null : (int)$cr['operation_is_functional'],
                    'operation_quantity' => $cr['operation_quantity'] === null ? null : (int)$cr['operation_quantity'],
                    'operation_condition' => $cr['operation_condition'] ?? null,
                    'operation_updated_at' => $cr['operation_updated_at']
                ];
            }

            for ($i = 0; $i < count($rooms); $i++) {
                $rid = (int)$rooms[$i]['room_id'];
                $rooms[$i]['checklist'] = $byRoom[$rid] ?? [];
            }

            return json_encode([
                'success' => true,
                'data' => $rooms
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getInspectionsByDate($data) {
        try {
            if (!is_array($data) || !isset($data['user_id'], $data['date'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required fields: user_id, date'
                ]);
            }

            $user_id = (int)$data['user_id'];
            $date = $data['date'];

            if ($user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid user_id.'
                ]);
            }

            $d = DateTime::createFromFormat('Y-m-d', $date);
            if (!$d || $d->format('Y-m-d') !== $date) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid date format. Use YYYY-MM-DD.'
                ]);
            }

            $assignmentStmt = $this->conn->prepare('
                SELECT assigned_id, assigned_floor_building_id
                FROM tblassigned
                WHERE assigned_user_id = ?
                  AND ? BETWEEN assigned_start_date AND assigned_end_date
                ORDER BY assigned_created_at DESC
                LIMIT 1
            ');
            $assignmentStmt->execute([$user_id, $date]);
            $assignment = $assignmentStmt->fetch(PDO::FETCH_ASSOC);

            if (!$assignment) {
                return json_encode([
                    'success' => true,
                    'data' => []
                ]);
            }

            $assigned_id = (int)$assignment['assigned_id'];
            $assigned_floor_building_id = (int)$assignment['assigned_floor_building_id'];

            $roomsStmt = $this->conn->prepare('
                SELECT
                    r.room_id,
                    r.room_number,
                    b.building_name,
                    f.floor_name,
                    s.assigned_status_id,
                    s.assigned_status,
                    s.assigned_remarks,
                    s.assigned_updated_at
                FROM tblroom r
                JOIN tblbuildingfloor bf ON bf.floorbuilding_id = r.room_building_floor_id
                JOIN tblbuilding b ON b.building_id = bf.building_id
                JOIN tblfloor f ON f.floor_id = bf.floor_id
                LEFT JOIN tblassignedstatus s
                    ON s.room_id = r.room_id
                    AND s.assigned_reported_by = ?
                    AND s.completion_date = ?
                WHERE r.room_building_floor_id = ?
                ORDER BY r.room_number ASC
            ');
            $roomsStmt->execute([$user_id, $date, $assigned_floor_building_id]);
            $rooms = $roomsStmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($rooms) === 0) {
                return json_encode([
                    'success' => true,
                    'data' => []
                ]);
            }

            $roomIds = array_map(function ($r) {
                return (int)$r['room_id'];
            }, $rooms);
            $placeholders = implode(',', array_fill(0, count($roomIds), '?'));

            $checklistStmt = $this->conn->prepare('
                SELECT
                    r.room_id,
                    c.checklist_id,
                    c.checklist_name,
                    c.checklist_type,
                    c.checklist_quantity,
                    o.operation_is_functional,
                    o.operation_quantity,
                    o.operation_condition,
                    o.operation_updated_at
                FROM tblroom r
                JOIN tblroomchecklist c ON c.checklist_room_id = r.room_id
                LEFT JOIN (
                    SELECT ao1.operation_room_id, ao1.operation_checklist_id, ao1.operation_is_functional, ao1.operation_quantity, ao1.operation_condition, ao1.operation_updated_at
                    FROM tblassignedoperation ao1
                    INNER JOIN (
                        SELECT operation_room_id, operation_checklist_id, MAX(operation_updated_at) AS max_updated_at
                        FROM tblassignedoperation
                        WHERE operation_updated_by = ? AND DATE(operation_updated_at) = ?
                        GROUP BY operation_room_id, operation_checklist_id
                    ) ao2
                        ON ao2.operation_room_id = ao1.operation_room_id
                        AND ao2.operation_checklist_id = ao1.operation_checklist_id
                        AND ao2.max_updated_at = ao1.operation_updated_at
                    WHERE ao1.operation_updated_by = ? AND DATE(ao1.operation_updated_at) = ?
                ) o
                    ON o.operation_room_id = r.room_id
                    AND o.operation_checklist_id = c.checklist_id
                WHERE r.room_id IN (' . $placeholders . ')
                ORDER BY r.room_id ASC, c.checklist_name ASC
            ');

            $params = [$user_id, $date, $user_id, $date];
            foreach ($roomIds as $rid) {
                $params[] = $rid;
            }
            $checklistStmt->execute($params);
            $checklistRows = $checklistStmt->fetchAll(PDO::FETCH_ASSOC);

            $byRoom = [];
            foreach ($checklistRows as $cr) {
                $rid = (int)$cr['room_id'];
                if (!isset($byRoom[$rid])) $byRoom[$rid] = [];
                $byRoom[$rid][] = [
                    'checklist_id' => (int)$cr['checklist_id'],
                    'checklist_name' => $cr['checklist_name'],
                    'checklist_type' => $cr['checklist_type'] ?? 'boolean',
                    'checklist_quantity' => $cr['checklist_quantity'] ?? null,
                    'operation_is_functional' => $cr['operation_is_functional'] === null ? null : (int)$cr['operation_is_functional'],
                    'operation_quantity' => $cr['operation_quantity'] === null ? null : (int)$cr['operation_quantity'],
                    'operation_condition' => $cr['operation_condition'] ?? null,
                    'operation_updated_at' => $cr['operation_updated_at']
                ];
            }

            for ($i = 0; $i < count($rooms); $i++) {
                $rid = (int)$rooms[$i]['room_id'];
                $rooms[$i]['assigned_id'] = $assigned_id;
                $rooms[$i]['is_missed'] = empty($rooms[$i]['assigned_status_id']);
                $rooms[$i]['checklist'] = $byRoom[$rid] ?? [];
            }

            return json_encode([
                'success' => true,
                'data' => $rooms
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getCurrentAssignment($data) {
        try {
            if (!is_array($data) || !isset($data['assigned_user_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_user_id'
                ]);
            }

            $assigned_user_id = (int)$data['assigned_user_id'];
            if ($assigned_user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_user_id.'
                ]);
            }

            $stmt = $this->conn->prepare('SELECT a.assigned_id, a.assigned_user_id, a.assigned_floor_building_id, bf.building_id, b.building_name, bf.floor_id, f.floor_name, a.assigned_start_date, a.assigned_end_date, a.assigned_by_user_id, a.assigned_created_at FROM tblassigned a JOIN tblbuildingfloor bf ON bf.floorbuilding_id = a.assigned_floor_building_id JOIN tblbuilding b ON b.building_id = bf.building_id JOIN tblfloor f ON f.floor_id = bf.floor_id WHERE a.assigned_user_id = ? AND CURDATE() BETWEEN a.assigned_start_date AND a.assigned_end_date ORDER BY a.assigned_created_at DESC LIMIT 1');
            $stmt->execute([$assigned_user_id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                $stmt2 = $this->conn->prepare('SELECT a.assigned_id, a.assigned_user_id, a.assigned_floor_building_id, bf.building_id, b.building_name, bf.floor_id, f.floor_name, a.assigned_start_date, a.assigned_end_date, a.assigned_by_user_id, a.assigned_created_at FROM tblassigned a JOIN tblbuildingfloor bf ON bf.floorbuilding_id = a.assigned_floor_building_id JOIN tblbuilding b ON b.building_id = bf.building_id JOIN tblfloor f ON f.floor_id = bf.floor_id WHERE a.assigned_user_id = ? ORDER BY a.assigned_created_at DESC LIMIT 1');
                $stmt2->execute([$assigned_user_id]);
                $row = $stmt2->fetch(PDO::FETCH_ASSOC);
            }

            return json_encode([
                'success' => true,
                'data' => $row
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getAssignedRooms($data) {
        try {
            $assigned_id = null;
            $assigned_user_id = null;
            $assigned_floor_building_id = null;

            if (is_array($data) && isset($data['assigned_id']) && $data['assigned_id'] !== '') {
                $assigned_id = (int)$data['assigned_id'];
            }
            if (is_array($data) && isset($data['assigned_user_id']) && $data['assigned_user_id'] !== '') {
                $assigned_user_id = (int)$data['assigned_user_id'];
            }
            if (is_array($data) && isset($data['assigned_floor_building_id']) && $data['assigned_floor_building_id'] !== '') {
                $assigned_floor_building_id = (int)$data['assigned_floor_building_id'];
            }

            if ($assigned_id) {
                $assignStmt = $this->conn->prepare('SELECT assigned_id, assigned_user_id, assigned_floor_building_id FROM tblassigned WHERE assigned_id = ? LIMIT 1');
                $assignStmt->execute([$assigned_id]);
                $row = $assignStmt->fetch(PDO::FETCH_ASSOC);
                if (!$row) {
                    return json_encode([
                        'success' => false,
                        'message' => 'Assignment not found.'
                    ]);
                }
                $assigned_floor_building_id = (int)($row['assigned_floor_building_id'] ?? 0);
                if (!$assigned_user_id) {
                    $assigned_user_id = (int)($row['assigned_user_id'] ?? 0);
                }
            }

            if (!$assigned_floor_building_id && $assigned_user_id) {
                $active = $this->getCurrentAssignment(['assigned_user_id' => $assigned_user_id]);
                $decoded = json_decode($active, true);
                if (is_array($decoded) && ($decoded['success'] ?? false) && is_array($decoded['data'] ?? null)) {
                    $assigned_floor_building_id = (int)($decoded['data']['assigned_floor_building_id'] ?? 0);
                    if (!$assigned_id) {
                        $assigned_id = (int)($decoded['data']['assigned_id'] ?? 0);
                    }
                }
            }

            if (!$assigned_floor_building_id) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_floor_building_id (or provide assigned_user_id with an assignment)'
                ]);
            }

            if (!$assigned_id) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: assigned_id'
                ]);
            }

            // Fetch only the assigned rooms from tblassignedrooms for this specific assignment
            $stmt = $this->conn->prepare('
                SELECT 
                    r.room_id, 
                    r.room_number, 
                    r.room_building_floor_id, 
                    bf.building_id, 
                    b.building_name, 
                    bf.floor_id, 
                    f.floor_name, 
                    CASE WHEN s.assigned_status_id IS NOT NULL THEN \'Done\' ELSE \'Pending\' END AS status 
                FROM tblassignedrooms ar
                JOIN tblroom r ON r.room_id = ar.assigned_room_id
                JOIN tblbuildingfloor bf ON bf.floorbuilding_id = r.room_building_floor_id 
                JOIN tblbuilding b ON b.building_id = bf.building_id 
                JOIN tblfloor f ON f.floor_id = bf.floor_id 
                LEFT JOIN tblassignedstatus s ON s.room_id = r.room_id AND s.assigned_id = ? AND s.completion_date = CURDATE() 
                WHERE ar.assigned_assigned_id = ?
                ORDER BY f.floor_name ASC, r.room_number ASC
            ');
            $stmt->execute([$assigned_id, $assigned_id]);
            $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return json_encode([
                'success' => true,
                'data' => $rooms
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getRoomChecklist($data) {
        try {
            if (!is_array($data) || !isset($data['room_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: room_id'
                ]);
            }

            $room_id = (int)$data['room_id'];
            if ($room_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid room_id.'
                ]);
            }

            $assigned_id = null;
            $reported_by = null;
            if (isset($data['assigned_id']) && $data['assigned_id'] !== '') {
                $assigned_id = (int)$data['assigned_id'];
            }
            if (isset($data['assigned_reported_by']) && $data['assigned_reported_by'] !== '') {
                $reported_by = (int)$data['assigned_reported_by'];
            }

            // Get the room's floorbuilding_id
            $roomStmt = $this->conn->prepare('SELECT room_building_floor_id FROM tblroom WHERE room_id = ?');
            $roomStmt->execute([$room_id]);
            $roomRow = $roomStmt->fetch(PDO::FETCH_ASSOC);
            if (!$roomRow) {
                return json_encode([
                    'success' => false,
                    'message' => 'Room not found.'
                ]);
            }
            $floorbuilding_id = (int)$roomRow['room_building_floor_id'];

            $inspection = null;
            $statusSql = 'SELECT assigned_status, assigned_remarks, completion_date, assigned_updated_at, assigned_reported_by, assigned_id, room_id FROM tblassignedstatus WHERE room_id = ? AND completion_date = CURDATE()';
            $statusParams = [$room_id];
            if ($assigned_id) {
                $statusSql .= ' AND assigned_id = ?';
                $statusParams[] = $assigned_id;
            }
            if ($reported_by) {
                $statusSql .= ' AND assigned_reported_by = ?';
                $statusParams[] = $reported_by;
            }
            $statusSql .= ' ORDER BY assigned_updated_at DESC LIMIT 1';
            $statusStmt = $this->conn->prepare($statusSql);
            $statusStmt->execute($statusParams);
            $inspectionRow = $statusStmt->fetch(PDO::FETCH_ASSOC);
            if ($inspectionRow) {
                $inspection = $inspectionRow;
            }

            if ($reported_by) {
                $stmt = $this->conn->prepare('SELECT c.checklist_id, c.checklist_name, c.checklist_room_id, c.checklist_type, c.checklist_quantity, c.checklist_options, o.operation_id, o.operation_is_functional, o.operation_quantity, o.operation_condition, o.operation_updated_at, o.operation_updated_by FROM tblroomchecklist c LEFT JOIN (SELECT ao1.operation_id, ao1.operation_is_functional, ao1.operation_quantity, ao1.operation_condition, ao1.operation_updated_at, ao1.operation_updated_by, ao1.operation_room_id, ao1.operation_checklist_id FROM tblassignedoperation ao1 INNER JOIN (SELECT operation_room_id, operation_checklist_id, MAX(operation_updated_at) AS max_updated_at FROM tblassignedoperation WHERE operation_updated_by = ? AND DATE(operation_updated_at) = CURDATE() GROUP BY operation_room_id, operation_checklist_id) ao2 ON ao2.operation_room_id = ao1.operation_room_id AND ao2.operation_checklist_id = ao1.operation_checklist_id AND ao2.max_updated_at = ao1.operation_updated_at WHERE ao1.operation_updated_by = ?) o ON o.operation_room_id = ? AND o.operation_checklist_id = c.checklist_id WHERE c.checklist_room_id = ? ORDER BY c.checklist_name ASC');
                $stmt->execute([$reported_by, $reported_by, $room_id, $room_id]);
            } else {
                $stmt = $this->conn->prepare('SELECT c.checklist_id, c.checklist_name, c.checklist_room_id, c.checklist_type, c.checklist_quantity, c.checklist_options, o.operation_id, o.operation_is_functional, o.operation_quantity, o.operation_condition, o.operation_updated_at, o.operation_updated_by FROM tblroomchecklist c LEFT JOIN (SELECT ao1.operation_id, ao1.operation_is_functional, ao1.operation_quantity, ao1.operation_condition, ao1.operation_updated_at, ao1.operation_updated_by, ao1.operation_room_id, ao1.operation_checklist_id FROM tblassignedoperation ao1 INNER JOIN (SELECT operation_room_id, operation_checklist_id, MAX(operation_updated_at) AS max_updated_at FROM tblassignedoperation WHERE DATE(operation_updated_at) = CURDATE() GROUP BY operation_room_id, operation_checklist_id) ao2 ON ao2.operation_room_id = ao1.operation_room_id AND ao2.operation_checklist_id = ao1.operation_checklist_id AND ao2.max_updated_at = ao1.operation_updated_at) o ON o.operation_room_id = ? AND o.operation_checklist_id = c.checklist_id WHERE c.checklist_room_id = ? ORDER BY c.checklist_name ASC');
                $stmt->execute([$room_id, $room_id]);
            }

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return json_encode([
                'success' => true,
                'data' => $rows,
                'inspection' => $inspection
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function saveChecklistOperation($data) {
        try {
            if (!is_array($data) || !isset($data['operation_room_id'], $data['operation_checklist_id'], $data['operation_is_functional'], $data['operation_updated_by'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required fields: operation_room_id, operation_checklist_id, operation_is_functional, operation_updated_by'
                ]);
            }

            $room_id = (int)$data['operation_room_id'];
            $checklist_id = (int)$data['operation_checklist_id'];
            $updated_by = (int)$data['operation_updated_by'];
            $value = $data['operation_is_functional']; // Can be 0/1 for boolean, number for quantity, or string for condition
            $assigned_id = isset($data['operation_assigned_id']) ? (int)$data['operation_assigned_id'] : null;

            if ($room_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid operation_room_id.'
                ]);
            }
            if ($checklist_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid operation_checklist_id.'
                ]);
            }
            if ($updated_by <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid operation_updated_by.'
                ]);
            }

            // If assigned_id not provided, look it up from current assignment
            if (!$assigned_id) {
                $assignStmt = $this->conn->prepare('
                    SELECT assigned_id 
                    FROM tblassigned 
                    WHERE assigned_user_id = ? 
                      AND CURDATE() BETWEEN assigned_start_date AND assigned_end_date 
                    ORDER BY assigned_created_at DESC 
                    LIMIT 1
                ');
                $assignStmt->execute([$updated_by]);
                $assignRow = $assignStmt->fetch(PDO::FETCH_ASSOC);
                if ($assignRow) {
                    $assigned_id = (int)$assignRow['assigned_id'];
                }
            }

            $checkRoom = $this->conn->prepare('SELECT room_id FROM tblroom WHERE room_id = ?');
            $checkRoom->execute([$room_id]);
            if (!$checkRoom->fetch(PDO::FETCH_ASSOC)) {
                return json_encode([
                    'success' => false,
                    'message' => 'Room not found.'
                ]);
            }

            // Get checklist type to determine how to store the value
            $checklistStmt = $this->conn->prepare('SELECT c.checklist_id, c.checklist_type, c.checklist_quantity FROM tblroomchecklist c WHERE c.checklist_id = ? AND c.checklist_room_id = ?');
            $checklistStmt->execute([$checklist_id, $room_id]);
            $checklistInfo = $checklistStmt->fetch(PDO::FETCH_ASSOC);
            if (!$checklistInfo) {
                return json_encode([
                    'success' => false,
                    'message' => 'Checklist item not found for this room.'
                ]);
            }
            
            $itemType = $checklistInfo['checklist_type'] ?? 'boolean';
            $expectedQty = $checklistInfo['checklist_quantity'] ?? null;

            // Determine values based on checklist type
            $isFunctional = null;
            $quantity = null;
            $condition = null;
            
            if ($itemType === 'quantity') {
                // Store quantity value
                $quantity = is_numeric($value) ? (int)$value : null;
                // Set is_functional based on whether quantity matches expected
                if ($quantity !== null && $expectedQty !== null) {
                    $isFunctional = $quantity >= $expectedQty ? 1 : 0;
                }
            } elseif ($itemType === 'condition') {
                // Store condition value
                $condition = trim((string)$value);
                // Set is_functional based on good condition keywords
                $goodOptions = ['good', 'clean', 'working', 'functional', 'ok'];
                $isFunctional = 0;
                foreach ($goodOptions as $good) {
                    if (stripos($condition, $good) !== false) {
                        $isFunctional = 1;
                        break;
                    }
                }
            } else {
                // Boolean type - store in is_functional
                $isFunctional = $this->normalizeChecklistStatus($value, 1);
            }

            $find = $this->conn->prepare('SELECT operation_id, operation_updated_at FROM tblassignedoperation WHERE operation_room_id = ? AND operation_checklist_id = ? ORDER BY operation_updated_at DESC LIMIT 1');
            $find->execute([$room_id, $checklist_id]);
            $existing = $find->fetch(PDO::FETCH_ASSOC);

            if ($existing && isset($existing['operation_updated_at']) && date('Y-m-d', strtotime($existing['operation_updated_at'])) === date('Y-m-d')) {
                $operation_id = (int)$existing['operation_id'];
                $upd = $this->conn->prepare('UPDATE tblassignedoperation SET operation_is_functional = ?, operation_quantity = ?, operation_condition = ?, operation_updated_at = NOW(), operation_updated_by = ?, operation_assigned_id = ? WHERE operation_id = ?');
                $upd->execute([$isFunctional, $quantity, $condition, $updated_by, $assigned_id, $operation_id]);
                return json_encode([
                    'success' => true,
                    'message' => 'Checklist operation updated successfully',
                    'operation_id' => $operation_id
                ]);
            }

            $ins = $this->conn->prepare('INSERT INTO tblassignedoperation (operation_is_functional, operation_quantity, operation_condition, operation_updated_at, operation_updated_by, operation_room_id, operation_checklist_id, operation_assigned_id) VALUES (?, ?, ?, NOW(), ?, ?, ?, ?)');
            $ins->execute([$isFunctional, $quantity, $condition, $updated_by, $room_id, $checklist_id, $assigned_id]);

            return json_encode([
                'success' => true,
                'message' => 'Checklist operation saved successfully',
                'operation_id' => $this->conn->lastInsertId()
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function getInspectionHistory($data) {
        try {
            if (!is_array($data) || !isset($data['user_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required field: user_id'
                ]);
            }

            $user_id = (int)$data['user_id'];
            if ($user_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid user_id.'
                ]);
            }

            $stmt = $this->conn->prepare('SELECT completion_date AS date, COUNT(assigned_status_id) AS count FROM tblassignedstatus WHERE assigned_reported_by = ? GROUP BY completion_date ORDER BY completion_date ASC');
            $stmt->execute([$user_id]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $assignStmt = $this->conn->prepare('SELECT assigned_id, assigned_start_date, assigned_end_date FROM tblassigned WHERE assigned_user_id = ? ORDER BY assigned_created_at DESC');
            $assignStmt->execute([$user_id]);
            $rawAssignments = $assignStmt->fetchAll(PDO::FETCH_ASSOC);

            $assignmentsById = [];
            foreach ($rawAssignments as $a) {
                $aid = (int)($a['assigned_id'] ?? 0);
                if ($aid <= 0) continue;
                if (!isset($assignmentsById[$aid])) {
                    $assignmentsById[$aid] = $a;
                }
            }
            $assignments = array_values($assignmentsById);

            return json_encode([
                'success' => true,
                'data' => $history,
                'assignments' => $assignments
            ]);
        } catch (PDOException $e) {
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }

    public function submitInspection($data) {
        try {
            if (!is_array($data) || !isset($data['assigned_id'], $data['assigned_status'], $data['assigned_reported_by'], $data['room_id'])) {
                return json_encode([
                    'success' => false,
                    'message' => 'Missing required fields: assigned_id, assigned_status, assigned_reported_by, room_id'
                ]);
            }

            $assigned_id = (int)$data['assigned_id'];
            $reported_by = (int)$data['assigned_reported_by'];
            $room_id = (int)$data['room_id'];
            $assigned_status = $this->normalizeAssignedStatus($data['assigned_status']);
            $assigned_remarks = isset($data['assigned_remarks']) ? trim((string)$data['assigned_remarks']) : '';
            $operations = is_array($data['operations'] ?? null) ? $data['operations'] : [];

            if ($assigned_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_id.'
                ]);
            }
            if ($reported_by <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_reported_by.'
                ]);
            }
            if ($room_id <= 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid room_id.'
                ]);
            }
            if (!$assigned_status) {
                return json_encode([
                    'success' => false,
                    'message' => 'Invalid assigned_status. Use Excellent, Good, Fair, or Poor.'
                ]);
            }
            if (count($operations) === 0) {
                return json_encode([
                    'success' => false,
                    'message' => 'No checklist selections submitted.'
                ]);
            }

            $this->conn->beginTransaction();

            $insStatus = $this->conn->prepare('INSERT INTO tblassignedstatus (assigned_id, room_id, assigned_remarks, assigned_status, assigned_reported_by, completion_date, assigned_updated_at) VALUES (?, ?, ?, ?, ?, CURDATE(), NOW())');
            $insStatus->execute([$assigned_id, $room_id, $assigned_remarks, $assigned_status, $reported_by]);

            // Get checklist types for the operations being submitted
            $checklistIds = array_filter(array_map(function($op) {
                return isset($op['checklist_id']) ? (int)$op['checklist_id'] : 0;
            }, $operations));
            
            $checklistTypes = [];
            if (count($checklistIds) > 0) {
                $placeholders = implode(',', array_fill(0, count($checklistIds), '?'));
                $typeStmt = $this->conn->prepare("SELECT checklist_id, checklist_type, checklist_quantity FROM tblroomchecklist WHERE checklist_id IN ($placeholders)");
                $typeStmt->execute($checklistIds);
                $typeRows = $typeStmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($typeRows as $row) {
                    $checklistTypes[(int)$row['checklist_id']] = [
                        'type' => $row['checklist_type'] ?? 'boolean',
                        'quantity' => $row['checklist_quantity'] ?? null
                    ];
                }
            }

            // Insert operation with appropriate column based on checklist type
            $insOperation = $this->conn->prepare('INSERT INTO tblassignedoperation (operation_is_functional, operation_quantity, operation_condition, operation_updated_at, operation_updated_by, operation_room_id, operation_checklist_id) VALUES (?, ?, ?, NOW(), ?, ?, ?)');

            foreach ($operations as $op) {
                $checklist_id = (int)($op['checklist_id'] ?? 0);
                $status = $op['status'] ?? null;
                if ($checklist_id <= 0 || $status === null || $status === '') {
                    continue;
                }
                
                $itemType = $checklistTypes[$checklist_id]['type'] ?? 'boolean';
                $expectedQty = $checklistTypes[$checklist_id]['quantity'] ?? null;
                
                $isFunctional = null;
                $quantity = null;
                $condition = null;
                
                if ($itemType === 'quantity') {
                    // Store quantity value
                    $quantity = is_numeric($status) ? (int)$status : null;
                    // Set is_functional based on whether quantity matches expected
                    if ($quantity !== null && $expectedQty !== null) {
                        $isFunctional = $quantity >= $expectedQty ? 1 : 0;
                    }
                } elseif ($itemType === 'condition') {
                    // Store condition value
                    $condition = trim((string)$status);
                    // Set is_functional based on good condition keywords
                    $goodOptions = ['good', 'clean', 'working', 'functional', 'ok'];
                    $isFunctional = 0;
                    foreach ($goodOptions as $good) {
                        if (stripos($condition, $good) !== false) {
                            $isFunctional = 1;
                            break;
                        }
                    }
                } else {
                    // Boolean type - store in is_functional
                    $isFunctional = $this->normalizeChecklistStatus($status, null);
                    if ($isFunctional === null) {
                        continue;
                    }
                }
                
                $insOperation->execute([$isFunctional, $quantity, $condition, $reported_by, $room_id, $checklist_id]);
            }

            $this->conn->commit();

            return json_encode([
                'success' => true,
                'message' => 'Inspection submitted successfully.'
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            return json_encode([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ]);
        }
    }
}

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $operation = $_GET['operation'] ?? '';
    $json = $_GET['json'] ?? [];
    if (is_string($json)) {
        $decoded = json_decode($json, true);
        if (is_array($decoded)) {
            $json = $decoded;
        }
    }
} else if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $operation = $body['operation'] ?? ($_POST['operation'] ?? '');
    $json = $body['json'] ?? ($_POST['json'] ?? []);
} else {
    $operation = '';
    $json = [];
}

$user = new Student($conn);

switch($operation){
    case 'getCurrentAssignment':
        echo $user->getCurrentAssignment($json);
        break;
    case 'getAssignments':
        echo $user->getAssignments($json);
        break;
    case 'getAssignedRooms':
        echo $user->getAssignedRooms($json);
        break;
    case 'getRoomChecklist':
        echo $user->getRoomChecklist($json);
        break;
    case 'saveChecklistOperation':
        echo $user->saveChecklistOperation($json);
        break;
    case 'getTodayActivity':
        echo $user->getTodayActivity($json);
        break;
    case 'getMissedClassrooms':
        echo $user->getMissedClassrooms($json);
        break;
    case 'submitInspection':
        echo $user->submitInspection($json);
        break;
    case 'getInspectionHistory':
        echo $user->getInspectionHistory($json);
        break;
    case 'getInspectionsByDate':
        echo $user->getInspectionsByDate($json);
        break;

    default:
        echo json_encode([
            'success' => false,
            'message' => 'Invalid operation'
        ]);
}

?>
